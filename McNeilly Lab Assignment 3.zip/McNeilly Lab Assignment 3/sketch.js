let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let fr = 30;


function setup() {

  createCanvas(1000,1000);
  background(100);


  frameRate(fr);

}

function draw() {

    colorMode(RGB, 255, 255, 255, 1);

    let mx = mouseX
    let my = mouseY
    let px = pmouseX
    let py = pmouseY

    //Blue Mouse drawing
    stroke(0,0,255);
    line(mx, my, px, py);


    //Green Upper Left Corner mini drawing
    stroke(0,255,0);
    line(sqrt(mx),sqrt(my),sqrt(px),sqrt(py));


    //Red Mouse drawing that's slightly next to your mouse
    stroke(255,0,0);
    line(abs(mx+5),abs(my+5),abs(px+5),abs(py+5));





}
