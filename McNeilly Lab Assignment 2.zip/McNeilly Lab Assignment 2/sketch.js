function setup() {
  // put setup code here
  createCanvas(256,256);
  background(100);
}

function draw() {

    colorMode(RGB, 255, 255, 255, 1);

    strokeWeight(2);
    // Red Triangle Balloon
    fill(255, 0, 0);

    triangle(25, 50, 17, 107, 38, 88);

    // Green titled square balloon
    fill(0, 255, 0);

    quad(220, 35, 225, 89, 177, 95, 170, 40);

    // Blue arc "Bowl" balloon
    fill(0, 0, 255);

    arc((256/2), (256/2), 40, 60, 0, PI, CHORD);

    //Purple Pentagon Balloon

    beginShape();
    fill(140, 0, 140);
    vertex(40, 170);
    vertex(20, 190);
    vertex(23, 230);
    vertex(57, 230);
    vertex(60, 190);
    endShape(CLOSE);

    //Yellow Pentagon Balloon

    beginShape();
    fill(150, 165, 0);
    vertex(216, 170);
    vertex(236, 190);
    vertex(233,230);
    vertex(199, 230);
    vertex(196, 190);
    endShape(CLOSE);



}
