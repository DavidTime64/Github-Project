function setup() {
  // put setup code here
  createCanvas(256,256);
  background(100);
}

function draw() {

    // strokeWeight(thickness);
    // The larger the number, the more thick the stroke.
    strokeWeight(2);

    // Think of the display window as a graphing calculator,
    // except the origin (0, 0) is in the upper left corner.
    // x increases as you travel to the right.
    // y increases as you travel to the bottom.
    // point(x, y);

    //Stars in the sky:
    point(10, 88);
    point(23, 48);
    point(100,70);
    point(77,55);
    point(123,45);
    point(95,20);
    point(57, 29);


    //Skyscaper
    strokeWeight(1);
    stroke(51);
    fill(20);
    rect(10,106,40,150);

    //Skyscraper antenna
    line(15,106,15,40);

    //Dome Building
    strokeWeight(70);
    stroke(51);
    strokeCap(ROUND);
    fill(20);
    line(110,190,110,256);

    //Moon outline
    noFill();
    strokeWeight(1);
    ellipse(200,50,100,100);

    //Hill Horrizon
    noStroke();
    fill(80);
    ellipse(128,256,300,70);


}
